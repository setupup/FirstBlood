/* Some fundamental exercises
$time$
HU Sheng, Essential C++ Chapter 

*/