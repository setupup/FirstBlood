/* Some fstream exercises
2015-4-17
HU Sheng, Essential C++ Chapter 1
*/
#include<iostream>
using namespace std;
